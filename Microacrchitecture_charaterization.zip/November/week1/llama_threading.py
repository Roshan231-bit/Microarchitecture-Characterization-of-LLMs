import os
from llama_cpp import Llama

# Restrict to one thread
os.environ["OMP_NUM_THREADS"] = "1"

# Define t`he model path
model_path = "/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b.Q5_K_M.gguf"

# Check if the model file exists
if not os.path.exists(model_path):
    print(f"Model file not found at {model_path}")
else:
    print("Model file found.")

# Load the LLaMA model
try:
    llm = Llama(
        model_path=model_path,
        n_ctx=512,  # Context window size
        n_threads=1,  # Number of threads to use
        use_mlock=False,  # Adjust according to your requirements
        use_mmap=True  # Use memory-mapped files for efficient loading
    )
    print("Model loaded successfully.")
except Exception as e:
    print(f"Error loading model: {e}")

# Generate output with a single prompt
try:
    output = llm(
        "Name the planets in the solar system.",  # Prompt without chat format
        max_tokens=100,  # Generate up to 100 tokens (reduce for testing)
        stop=["\n"],  # Stop at a newline
    )

    # Print the raw output to inspect the structure
    print("Raw output:", output)

    # Print the generated response if available
    if "choices" in output and len(output["choices"]) > 0:
        print("Generated text:", output["choices"][0]["text"].strip())  # Use .strip() to clean up output
    else:
        print("No output generated or unexpected output structure.")
except Exception as e:
    print(f"Error generating output: {e}")
