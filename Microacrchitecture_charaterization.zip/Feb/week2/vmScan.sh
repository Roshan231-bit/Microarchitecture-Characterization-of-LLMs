#!/bin/bash

# Activate the conda environment
source activate myenv

# Run your Python script in the background and capture the PID
python Elapsed_llama1.py &  # Run your Python script in the background
PYTHON_PID=$!

# Wait for a moment to ensure the process starts
sleep 2

# Create or clear the output file
echo "Timestamp,Counts" > vmScan_output.txt

# Start capturing the vmscan:mm_vmscan_kswapd_wake counts every second
echo "Capturing vmscan:mm_vmscan_kswapd_wake counts..."

# Use perf stat to collect the vmscan:mm_vmscan_kswapd_wake counts every second
perf stat -e vmscan:mm_vmscan_kswapd_wake -I 1000 -p $PYTHON_PID &> perf_output.txt &

# Store the PID of the perf command
PERF_PID=$!

# Monitor and capture the output
while true; do
    # Get the current timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")

    # Extract the relevant information from the perf output
    counts=$(grep "vmscan:mm_vmscan_kswapd_wake" perf_output.txt | tail -n 1 | awk '{print $1}')

    # Append the timestamp and counts to the output file
    echo "$timestamp,$counts" >> vmScan_output.txt

    # Wait 1 second before the next iteration
    sleep 1
done
