from llama_cpp import Llama
import os
file1 = open("myfile.txt", "w")  # write mode

# Restrict to one thread
os.environ["OMP_NUM_THREADS"] = "1"
file1.write("Before Llama")

# Load the LLaMA model with restricted threads
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
    n_ctx=2048,  # Increased context window size
    n_threads=1,  # Restrict to one thread for model execution
    n_batch=1
)

file1.write("Model Loaded")

# Update prompt to require more detailed explanation
prompt = (
    "Q: Can you explain in detail the solar system, including the names of all the planets, "
    "the characteristics of each planet, their positions relative to the sun, and the overall structure of the solar system? "
    "Please include information about moons, dwarf planets, and any interesting facts. A: "
)

# Generate output with a larger prompt and increased token generation
output = llm(
    prompt,  # Prompt
    max_tokens=2048,  # Increase max tokens for a longer response
    stop=["Q:", "\n"],  # Stop at a new question or newline
    echo=True  # Echo the prompt back in the output
)

# Print the generated response
print(output)

file1.write(str(output))
file1.close()
