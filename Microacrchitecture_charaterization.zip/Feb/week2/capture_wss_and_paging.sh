#!/bin/bash

# Activate the conda environment
source activate myenv

# Run your Python script in the background and capture the PID
python Elapsed_llama1.py &  # Run your Python script in the background
PYTHON_PID=$!

# Wait for a moment to ensure the process starts
sleep 2

# Create or clear the WSS.txt file and add headers for vmstat
echo "Timestamp,PID,procs,r,b,swpd,free,buff,cache,si,so,bi,bo,in,cs,us,sy,id,wa,st" > WSS.txt

# Capture vmstat and WSS data for 1-second intervals
echo "Capturing vmstat and WSS metrics for PID $PYTHON_PID..."

# Loop for capturing metrics every second
for ((i=1; i<=60; i++)); do
    # Capture the current timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Run vmstat to get memory and swap statistics
    vmstat_output=$(vmstat 1 2 | tail -n 1)

    # Extract the relevant columns from vmstat output
    procs_r=$(echo $vmstat_output | awk '{print $1}')   # r (run queue)
    procs_b=$(echo $vmstat_output | awk '{print $2}')   # b (blocked processes)
    swpd=$(echo $vmstat_output | awk '{print $3}')      # swpd (swap usage)
    free=$(echo $vmstat_output | awk '{print $4}')      # free (free memory)
    buff=$(echo $vmstat_output | awk '{print $5}')      # buff (buffer memory)
    cache=$(echo $vmstat_output | awk '{print $6}')     # cache (cache memory)
    si=$(echo $vmstat_output | awk '{print $7}')        # si (swap in)
    so=$(echo $vmstat_output | awk '{print $8}')        # so (swap out)
    bi=$(echo $vmstat_output | awk '{print $9}')        # bi (blocks in)
    bo=$(echo $vmstat_output | awk '{print $10}')       # bo (blocks out)
    in=$(echo $vmstat_output | awk '{print $11}')       # in (interrupts)
    cs=$(echo $vmstat_output | awk '{print $12}')       # cs (context switches)
    us=$(echo $vmstat_output | awk '{print $13}')       # us (user CPU time)
    sy=$(echo $vmstat_output | awk '{print $14}')       # sy (system CPU time)
    id=$(echo $vmstat_output | awk '{print $15}')       # id (idle CPU time)
    wa=$(echo $vmstat_output | awk '{print $16}')       # wa (waiting for I/O)
    st=$(echo $vmstat_output | awk '{print $17}')       # st (stolen CPU time)

    # Append the data to WSS.txt
    echo "$timestamp,$PYTHON_PID,$procs_r,$procs_b,$swpd,$free,$buff,$cache,$si,$so,$bi,$bo,$in,$cs,$us,$sy,$id,$wa,$st" >> WSS.txt

    # Sleep for 1 second
    sleep 1
done

# Optionally, kill the Python process after collecting data
kill $PYTHON_PID

echo "vmstat and WSS metrics collection completed. Data saved to WSS.txt."
