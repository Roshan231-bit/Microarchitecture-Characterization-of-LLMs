#!/bin/bash

# Activate the conda environment
source activate myenv

# Run your Python script in the background and capture the PID
python Elapsed_llama1.py &  # Run your Python script in the background
PYTHON_PID=$!

# Wait for a moment to ensure the process starts
sleep 2

# Create or clear the output file
echo "K_CYCLES,K_INSTR,IPC,BR_RETIRED,BR_MISPRED,BMR%,LLCREF,LLCMISS,LLC%" > perf_metrics_output.txt

# Start capturing the performance metrics every second
echo "Capturing performance metrics..."

# Use perf stat to collect performance data for the Python process
while true; do
    # Capture performance metrics for the running Python process
    metrics=$(perf stat -e cycles,instructions,branches,branch-misses,LLC-loads,LLC-load-misses -p $PYTHON_PID -x, -r 1 sleep 1)

    # Parse the output to extract the relevant values
    K_CYCLES=$(echo "$metrics" | grep cycles | awk '{print $1}')
    K_INSTR=$(echo "$metrics" | grep instructions | awk '{print $1}')
    IPC=$(echo "$metrics" | grep instructions | awk '{print $1}' | awk -v cycles="$K_CYCLES" '{print $1/cycles}')
    BR_RETIRED=$(echo "$metrics" | grep branches | awk '{print $1}')
    BR_MISPRED=$(echo "$metrics" | grep branch-misses | awk '{print $1}')
    LLCREF=$(echo "$metrics" | grep "LLC-loads" | awk '{print $1}')
    LLCMISS=$(echo "$metrics" | grep "LLC-load-misses" | awk '{print $1}')

    # Calculate LLC% based on the formula
    if [ "$LLCREF" -ne 0 ]; then
        LLC_PERCENT=$(echo "scale=2; $LLCMISS/$LLCREF * 100" | bc)
    else
        LLC_PERCENT=0
    fi

    # Append the collected metrics to the output file
    echo "$K_CYCLES,$K_INSTR,$IPC,$BR_RETIRED,$BR_MISPRED,$LLC_PERCENT,$LLCREF,$LLCMISS,$LLC_PERCENT" >> perf_metrics_output.txt

    # Check if the Python process is still running, exit if it's done
    if ! kill -0 $PYTHON_PID 2>/dev/null; then
        break
    fi
done
