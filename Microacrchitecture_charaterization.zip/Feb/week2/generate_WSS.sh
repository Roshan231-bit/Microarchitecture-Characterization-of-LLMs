#!/bin/bash

# Activate the conda environment
source activate myenv

# Run your Python script in the background and capture the PID
python Elapsed_llama1.py &  # Run your Python script in the background
PYTHON_PID=$!

# Wait for a moment to ensure the process starts
sleep 2

# Create or clear the WSS.txt file
echo "Timestamp,PID,WSS_Metrics" > WSS.txt

# Capture WSS data for 1 second interval
echo "Capturing WSS metrics for PID $PYTHON_PID..."

# Loop for capturing metrics every second
for ((i=1; i<=60; i++)); do
    # Capture the current timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Run the wss.pl script and get the working set size
    wss_output=$(./wss.pl $PYTHON_PID 0.1)
    
    # Append the data to WSS.txt
    echo "$timestamp,$PYTHON_PID,$wss_output" >> WSS.txt
    
    # Sleep for 1 second
    sleep 1
done

# Optionally: You can kill the process after the collection is done
kill $PYTHON_PID

echo "WSS metrics collection completed. Data saved to WSS.txt."
