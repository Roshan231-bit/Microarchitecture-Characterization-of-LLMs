#!/bin/bash

# Output file for workload metrics
TXT_OUTPUT="wss_workload.txt"

# Start with a clean output file or create it if it does not exist
echo "Duration(s)    RSS(MB)    PSS(MB)    Ref(MB)" > $TXT_OUTPUT

# Activate the environment before running the Python script
source activate myenv

# Run your Python script in the background and capture the PID
python Elapsed_llama1.py &  # Run your Python script in the background
PYTHON_PID=$!

# Wait for a moment to ensure the process starts
sleep 5  # Wait for 5 seconds for the model to initialize

# Print starting message for the workload
echo "Watching PID $PYTHON_PID page references during 1, 10, and 60 seconds..."

# Function to run wss.pl for a specific duration and append results to the output file
run_wss_for_duration() {
    local duration=$1
    echo "Running wss.pl for $duration seconds..."
    ./wss.pl $PYTHON_PID $duration 2>&1 | while read line; do
        # Extract the Est(s), RSS(MB), PSS(MB), Ref(MB) columns
        if [[ "$line" =~ "Est\(s\)\s+RSS\(MB\)\s+PSS\(MB\)\s+Ref\(MB\)" ]]; then
            continue  # Skip the header line
        fi
        EST=$(echo $line | awk '{print $1}')
        RSS=$(echo $line | awk '{print $2}')
        PSS=$(echo $line | awk '{print $3}')
        REF=$(echo $line | awk '{print $4}')

        # Append to the .txt file
        echo "$duration    $RSS    $PSS    $REF" >> $TXT_OUTPUT
    done
}

# Run wss.pl for 1 second
run_wss_for_duration 1

# Run wss.pl for 10 seconds
run_wss_for_duration 10

# Run wss.pl for 60 seconds
run_wss_for_duration 60

# Notify the user where the metrics have been saved
echo "Metrics have been saved to $TXT_OUTPUT"

