#!/bin/bash

# Output file for workload metrics
TXT_OUTPUT="wss_workload_monitor.txt"

# Start with a clean output file or create it if it does not exist
echo "Est(s)     RSS(MB)    PSS(MB)    Ref(MB)" > $TXT_OUTPUT

# Activate the conda environment
source activate myenv

# Run the LLaMA script in the background and capture the PID
python Elapsed_llama1.py &  
LLAMA_PID=$!

# Wait a few seconds to ensure the process starts
sleep 2  

# Check if the process is running
if ! ps -p $LLAMA_PID > /dev/null; then
    echo "Error: Elapsed_llama1.py did not start properly"
    exit 1
fi

# Print PID for debugging purposes
echo "Using PID $LLAMA_PID for page reference tracking..."
echo "Watching PID $LLAMA_PID page references grow, output every 1 second..."

# Run wss continuously, capturing output every 1 second
./wss $LLAMA_PID 1 | tee -a $TXT_OUTPUT
