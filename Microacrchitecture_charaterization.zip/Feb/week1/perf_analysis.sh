#!/bin/bash

# Run perf stat and save output to temp file
perf stat -e instructions,L1-dcache-loads,L1-dcache-load-misses,L1-icache-load-misses,L2_rqsts.demand_data_rd_miss,LLC-loads,LLC-load-misses \
/home/msp/miniconda3/envs/Roshan/bin/python /home/msp/Documents/Roshan/Vtune_wokk/october/week2/Elapsed_llama.py 2> temp_output.txt

# Extract values from perf output
INSTRUCTIONS=$(grep "instructions" temp_output.txt | awk '{print $1}' | tr -d ',')
L1D_LOADS=$(grep "L1-dcache-loads" temp_output.txt | awk '{print $1}' | tr -d ',')
L1D_MISSES=$(grep "L1-dcache-load-misses" temp_output.txt | awk '{print $1}' | tr -d ',')
L1I_MISSES=$(grep "L1-icache-load-misses" temp_output.txt | awk '{print $1}' | tr -d ',')
L2_MISSES=$(grep "L2_rqsts.demand_data_rd_miss" temp_output.txt | awk '{print $1}' | tr -d ',')
LLC_LOADS=$(grep "LLC-loads" temp_output.txt | awk '{print $1}' | tr -d ',')
LLC_MISSES=$(grep "LLC-load-misses" temp_output.txt | awk '{print $1}' | tr -d ',')

# Calculate Miss Ratios
L1D_MISS_RATIO=$(awk "BEGIN {if ($L1D_LOADS > 0) printf \"%.2f\", ($L1D_MISSES / $L1D_LOADS) * 100; else print \"0\"}")
L1I_MISS_RATIO=$(awk "BEGIN {if ($INSTRUCTIONS > 0) printf \"%.2f\", ($L1I_MISSES / $INSTRUCTIONS) * 100; else print \"0\"}")
L2_MISS_RATIO=$(awk "BEGIN {if ($L1D_LOADS > 0) printf \"%.2f\", ($L2_MISSES / $L1D_LOADS) * 100; else print \"0\"}")
LLC_MISS_RATIO=$(awk "BEGIN {if ($LLC_LOADS > 0) printf \"%.2f\", ($LLC_MISSES / $LLC_LOADS) * 100; else print \"0\"}")

# Calculate MPKI
L1D_MPKI=$(awk "BEGIN {if ($INSTRUCTIONS > 0) printf \"%.2f\", ($L1D_MISSES / $INSTRUCTIONS) * 1000; else print \"0\"}")
L1I_MPKI=$(awk "BEGIN {if ($INSTRUCTIONS > 0) printf \"%.2f\", ($L1I_MISSES / $INSTRUCTIONS) * 1000; else print \"0\"}")
L2_MPKI=$(awk "BEGIN {if ($INSTRUCTIONS > 0) printf \"%.2f\", ($L2_MISSES / $INSTRUCTIONS) * 1000; else print \"0\"}")
LLC_MPKI=$(awk "BEGIN {if ($INSTRUCTIONS > 0) printf \"%.2f\", ($LLC_MISSES / $INSTRUCTIONS) * 1000; else print \"0\"}")

# Write results to output.txt
{
  echo "Performance Metrics for Elapsed_llama.py"
  echo "========================================="
  echo "Instructions: $INSTRUCTIONS"
  echo "L1 Data Cache Loads: $L1D_LOADS"
  echo "L1 Data Cache Load Misses: $L1D_MISSES"
  echo "L1 Instruction Cache Load Misses: $L1I_MISSES"
  echo "L2 Demand Data Read Misses: $L2_MISSES"
  echo "LLC Loads: $LLC_LOADS"
  echo "LLC Load Misses: $LLC_MISSES"
  echo ""
  echo "Miss Ratios:"
  echo "L1D Miss Ratio: $L1D_MISS_RATIO%"
  echo "L1I Miss Ratio: $L1I_MISS_RATIO%"
  echo "L2 Miss Ratio: $L2_MISS_RATIO%"
  echo "LLC Miss Ratio: $LLC_MISS_RATIO%"
  echo ""
  echo "MPKI (Misses Per Kilo Instructions):"
  echo "L1D MPKI: $L1D_MPKI"
  echo "L1I MPKI: $L1I_MPKI"
  echo "L2 MPKI: $L2_MPKI"
  echo "LLC MPKI: $LLC_MPKI"
} > output.txt

# Cleanup
rm temp_output.txt

echo "Analysis complete. Results saved in output.txt."
