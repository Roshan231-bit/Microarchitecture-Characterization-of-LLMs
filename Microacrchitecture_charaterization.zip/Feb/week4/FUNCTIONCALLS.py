import sys
import os
from llama_cpp import Llama

# Open a file to log function call details
trace_file = open("funtioncall.txt", "w")

def trace_calls(frame, event, arg):
    if event == "call":
        code = frame.f_code
        func_name = code.co_name
        filename = code.co_filename

        # Filter to only log functions from the llama_cpp module
        if "llama_cpp" in filename:
            log_line = f"Function: {func_name} | File: {filename}\n"
            trace_file.write(log_line)
            trace_file.flush()  # Make sure it's written immediately
    return trace_calls

sys.settrace(trace_calls)

# Run your LLaMA model code
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
    n_ctx=512,
    n_threads=1,
    n_batch=1
)

prompt = "Q: What is the capital of France? A: "
output = llm(prompt, max_tokens=50, stop=["Q:", "\n"], echo=True)

# Optionally print the output
print(output)

# Stop tracing and close the file
sys.settrace(None)
trace_file.close()
