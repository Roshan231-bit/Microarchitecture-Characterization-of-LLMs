#!/bin/bash
# This script automatically sends "step" commands to pdb for the file debug_pyhon.py
# and saves the complete debugger output to out_debug2.txt.

# Remove any existing output file
rm -f out_debug2.txt

# An infinite loop to continually output "step" commands.
# When debug_pyhon.py terminates, the loop will be broken by the closed pipe.
while true; do
    echo step
done | python -m pdb debug_pyhon.py | tee out_debug2.txt
