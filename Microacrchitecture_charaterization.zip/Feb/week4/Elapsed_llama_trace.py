import sys
import os
from collections import defaultdict
from llama_cpp import Llama

# File to store function trace
trace_file = open("trace_output.txt", "w")

# Dictionary to count function calls
function_counts = defaultdict(int)

# List to track execution order
execution_order = []

def trace_calls(frame, event, arg):
    if event == "call":
        code = frame.f_code
        func_name = code.co_name
        filename = code.co_filename

        if "llama_cpp" in filename:  # Filter for llama_cpp functions
            function_counts[func_name] += 1  # Count function calls
            execution_order.append(func_name)  # Track execution order

    return trace_calls

sys.settrace(trace_calls)

# Run your LLaMA model code
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
    n_ctx=512,
    n_threads=1,
    n_batch=1
)

prompt = "Q: What is the capital of France? A: "
output = llm(prompt, max_tokens=50, stop=["Q:", "\n"], echo=True)

# Print the output (optional)
print(output)

# Stop tracing
sys.settrace(None)

# Write function call summary to the file
trace_file.write("Function Call Counts:\n")
for func, count in function_counts.items():
    trace_file.write(f"{func}: {count} times\n")

trace_file.write("\nExecution Order:\n")
trace_file.write(" → ".join(execution_order) + "\n")

# Close the trace file
trace_file.close()
