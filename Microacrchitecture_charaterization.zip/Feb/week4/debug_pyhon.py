import pdb
from llama_cpp import Llama

def run_model():
    pdb.set_trace()  # Debugger will pause here
    llm = Llama(
        model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
        n_ctx=512,
        n_threads=1,
        n_batch=1
    )
    prompt = "Q: What is the capital of France? A: "
    output = llm(prompt, max_tokens=50, stop=["Q:", "\n"], echo=True)
    print(output)

run_model()
