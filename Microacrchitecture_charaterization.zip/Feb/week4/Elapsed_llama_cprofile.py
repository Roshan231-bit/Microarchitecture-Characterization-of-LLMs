import cProfile
import pstats
import pdb; pdb.set_trace()

from llama_cpp import Llama

def run_model():
    llm = Llama(
        model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
        n_ctx=512,
        n_threads=1,
        n_batch=1
    )
    prompt = "Q: What is the capital of France? A: "
    output = llm(prompt, max_tokens=50, stop=["Q:", "\n"], echo=True)
    print(output)

with cProfile.Profile() as pr:
    run_model()

stats = pstats.Stats(pr)
stats.sort_stats("cumulative").print_stats(50)  # Print top 50 functions
