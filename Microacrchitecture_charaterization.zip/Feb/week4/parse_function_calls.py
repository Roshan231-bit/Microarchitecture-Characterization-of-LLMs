#!/usr/bin/env python3
import os
import re
from collections import defaultdict

def parse_function_calls(filename):
    """
    Parses a text file with lines like:
    "Function: <function_name> | File: <full_file_path>"
    Returns a list of (function, file_name) tuples (excluding full paths).
    """
    func_calls = []
    with open(filename, "r") as f:
        for line in f:
            match = re.match(r"Function:\s*(\S+)\s*\|\s*File:\s*(.*/)?([^/]+)$", line)
            if match:
                func = match.group(1)
                file_name = match.group(3)  # Extract only the file name
                func_calls.append((func, file_name))
    return func_calls

def build_function_flow(calls):
    """
    Builds a function call flow (which function follows which) as a directed graph.
    """
    function_flow = defaultdict(set)
    prev_func = None
    for func, file_name in calls:
        if prev_func:
            function_flow[prev_func].add(func)
        prev_func = func
    return function_flow

def trace_to_so_files(calls):
    """
    Traces function calls leading to .so file accesses.
    """
    path_to_so = []
    for func, file_name in calls:
        path_to_so.append((func, file_name))
        if file_name.endswith(".so"):
            break  # Stop at the first .so file access
    return path_to_so

def main():
    input_file = "functioncall.txt"
    if not os.path.exists(input_file):
        print(f"File '{input_file}' not found!")
        return
    
    calls = parse_function_calls(input_file)
    function_flow = build_function_flow(calls)
    path_to_so = trace_to_so_files(calls)
    
    # Save function call flow to output file
    with open("functionCall2.txt", "w") as f:
        f.write("Function Call Flow:\n")
        for func, followers in function_flow.items():
            f.write(f"{func} -> {', '.join(followers)}\n")
        
        f.write("\nPath to .so file:\n")
        for func, file_name in path_to_so:
            f.write(f"{func} ({file_name})\n")

if __name__ == "__main__":
    main()
