from llama_cpp import Llama

# Load the LLaMA model
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b.Q5_K_M.gguf",
    n_ctx=512,  # Context window size
    n_threads=1,  # Number of threads to use
)

print("Model loaded successfully.")

# Generate output with a single prompt
output = llm(
    "Name the planets in the solar system.",  # Prompt without chat format
    max_tokens=512,  # Generate up to 512 tokens
    stop=["\n"],  # Stop at a newline
)

# Print the raw output to inspect the structure
print("Raw output:", output)

# Print the generated response if available
if "choices" in output and len(output["choices"]) > 0:
    print(output["choices"][0]["text"].strip())  # Use .strip() to clean up output
else:
    print("No output generated or unexpected output structure.")
