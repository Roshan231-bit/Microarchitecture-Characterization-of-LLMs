import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import os
import time

# Restrict to one thread
torch.set_num_threads(1)  # PyTorch CPU threads

# Check if CUDA (GPU) is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Load a pretrained CNN model (ResNet18)
model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
model = model.to(device)
model.eval()

# Dummy input tensor (batch size = 1, 3 color channels, 224x224 image)
dummy_input = torch.randn(1, 3, 224, 224).to(device)

# Run the model for at least 2 minutes
start_time = time.time()
end_time = start_time + 2 * 60  # 2 minutes from start time

while time.time() < end_time:
    model(dummy_input)  # Perform inference

print("Model has run for 2 minutes.")
