from llama_cpp import Llama
import os

# Restrict execution to one thread
os.environ["OMP_NUM_THREADS"] = "1"  # Restrict OpenMP to one thread
os.environ["LLAMA_NUM_THREADS"] = "1"  # Ensure llama-cpp runs in a single thread

# Open file for logging
with open("myfile.txt", "w") as file1:
    file1.write("Before Llama\n")

    # Load the LLaMA model with one thread
    llm = Llama(
        model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
        n_ctx=2048,  # Context size
        n_threads=1,  # Ensure model execution is limited to one thread
        n_batch=1
    )

    file1.write("Model Loaded\n")

    # Define the prompt
    prompt = (
        "Q: Explain the solar system briefly, covering the planets and their main characteristics. A: "
    )

    # Generate output
    output = llm(
        prompt,
        max_tokens=1024,  # Reduce tokens to fit within ~3 min execution time
        stop=["Q:", "\n"],  # Stop at a new question or newline
        echo=True  # Echo the prompt in the output
    )

    # Log the output
    file1.write(str(output))

# Print the generated response
print(output)
