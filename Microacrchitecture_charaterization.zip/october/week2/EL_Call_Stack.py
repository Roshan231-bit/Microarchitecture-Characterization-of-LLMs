import inspect
from llama_cpp import Llama
import os

# Function to log call stack
def log_call_stack(file):
    file.write("\n--- Call Stack Trace ---\n")
    for frame in inspect.stack():
        file.write(f"{frame.function} - {frame.filename}:{frame.lineno}\n")
    file.write("------------------------\n")

# Open the file to write
file1 = open("callstack_output.txt", "w")  # write mode

# Restrict to one thread
os.environ["OMP_NUM_THREADS"] = "1"
file1.write("Before Llama\n")
log_call_stack(file1)  # Log call stack before loading the model

# Load the LLaMA model with restricted threads
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
    n_ctx=512,  # Context window size
    n_threads=1,  # Restrict to one thread for model execution
    n_batch=1
)

file1.write("Model Loaded\n")
log_call_stack(file1)  # Log call stack after loading the model

prompt = "Q: Explain in detail the solar system, including the names of all the planets. A: "

# Generate output with a single prompt
output = llm(
    prompt,  # Prompt
    max_tokens=128,  # Generate up to 128 tokens
    stop=["Q:", "\n"],  # Stop at a new question or newline
    echo=True  # Echo the prompt back in the output
)

# Print the generated response
print(output)

file1.write(str(output) + "\n")
log_call_stack(file1)  # Log call stack after generation

file1.close()
