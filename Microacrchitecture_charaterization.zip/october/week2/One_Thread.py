from llama_cpp import Llama
import os

# Restrict OpenMP and other parallel libraries to one thread
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["TBB_NUM_THREADS"] = "1"

file1 = open("myfile.txt", "w")  # Write mode
file1.write("Before Llama\n")

# Load LLaMA model with single-threaded execution
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
    n_ctx=2048,   # Context size
    n_threads=1,  # Ensure single-threaded execution
    n_threads_batch=1,
    n_batch=1,    # Process 1 token at a time
    numa=False    # Disable NUMA optimizations
)

file1.write("Model Loaded\n")

# Shortened prompt
prompt = (
    "Q: Explain the solar system, naming all planets, their characteristics, positions, and structure. "
    "Include moons, dwarf planets, and interesting facts. A: "
)

# Generate output with a single prompt (limit execution time)
output = llm(
    prompt,
    max_tokens=256,  # Reduce output size further
    stop=["Q:", "\n"],  # Stop at a new question or newline
    echo=True
)

# Print the generated response
print(output)

# Save output to file
file1.write(str(output))
file1.close()
