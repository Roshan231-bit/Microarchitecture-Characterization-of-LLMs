from llama_cpp import Llama
import os
file1 = open("myfile.txt", "w")  # write mode

# Restrict to one thread
os.environ["OMP_NUM_THREADS"] = "1"
file1.write("Before Llama")
# Load the LLaMA model with restricted threads
llm = Llama(
    model_path="/home/msp/Documents/Roshan/Roshan_project/gguf/llama-2-7b-chat.Q2_K.gguf",
    n_ctx=1024,  # Context window size
    n_threads=1,  # Restrict to one thread for model execution
    n_batch=1
)

file1.write("Model Loaded")
#prompt = "Q: Name the planets in the solar system briefly. A:  "
prompt = (
    "Q: How do sallu finish his phd in 2 years. A: "
)

# Generate output with a single prompt
output = llm(
    prompt, # Prompt
    max_tokens= 2048,  # Generate up to 512 tokens
    stop=["Q:", "\n"],  # Stop at a new question or newline
    echo=True  # Echo the prompt back in the output
)

# Print the generated response
print(output)

