import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
#import psutil
#import time
#import os
#import csv

# Check if CUDA (GPU) is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

 #Load a pretrained CNN model (ResNet18)
model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
model = model.to(device)
model.eval()

# Dummy input tensor (batch size = 1, 3 color channels, 224x224 image)
dummy_input = torch.randn(1, 3, 224, 224).to(device)
model(dummy_input)
#
## Performance monitoring function
#def measure_performance(model, input_tensor, num_iterations=100):
#    cpu_before = psutil.cpu_percent(interval=None)
#    mem_before = psutil.virtual_memory().used / (1024 * 1024)  # Convert to MB
#
#    # Measure inference time
#    start_time = time.time()
#    with torch.no_grad():
#        for _ in range(num_iterations):
#            model(input_tensor)
#    end_time = time.time()
#
#    cpu_after = psutil.cpu_percent(interval=None)
#    mem_after = psutil.virtual_memory().used / (1024 * 1024)  # Convert to MB
#
#    inference_latency = (end_time - start_time) / num_iterations  # Average latency
#    cpu_usage = (cpu_before, cpu_after)
#    mem_usage = (mem_before, mem_after)
#
#    return inference_latency, cpu_usage, mem_usage
#
## Run the performance test
#num_iterations = 100
#latency, cpu_util, mem_util = measure_performance(model, dummy_input, num_iterations)
#
## Print results
#print(f"Inference Latency: {latency:.6f} seconds")
#print(f"CPU Utilization Before: {cpu_util[0]:.2f}%")
#print(f"CPU Utilization After: {cpu_util[1]:.2f}%")
#print(f"Memory Usage Before: {mem_util[0]:.2f} MB")
#print(f"Memory Usage After: {mem_util[1]:.2f} MB")
#
## Save results to CSV
#output_file = "cnn_performance_results.csv"
#file_exists = os.path.isfile(output_file)
#
#with open(output_file, mode="a", newline="") as file:
#    writer = csv.writer(file)
#    if not file_exists:
#        writer.writerow(["Device", "Latency (s)", "CPU Before (%)", "CPU After (%)", "Memory Before (MB)", "Memory After (MB)"])
#    writer.writerow([device, latency, cpu_util[0], cpu_util[1], mem_util[0], mem_util[1]])
#
#print(f"Results saved to {output_file}")
#